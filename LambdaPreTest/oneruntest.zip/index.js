import {
  S3Client,
  ListObjectsV2Command,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import mongoose from "mongoose";
import { Readable } from "stream";

/**
 * Lambda function handler for data insertion and testing maximum file size
 * @param {Object} event - Lambda event object
 * @param {Object} context - Lambda context object
 * @returns {Object} - Promise resolving the final status
 */
export const handler = async (event, context) => {
  try {
    // Create an S3 instance
    const s3 = new S3Client({ region: "us-east-2" });
    const bucketName = process.env.S3_BUCKET_NAME;

    // Connect to MongoDB using the environment variable
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB");

    // Create a schema for the video data
    const chunkSchema = new mongoose.Schema({
      chunkId: String,
      data: Buffer,
    });
    const VideoChunk = mongoose.model("VideoChunk", chunkSchema);

    // List objects in the bucket
    const listObjectsCommand = new ListObjectsV2Command({ Bucket: bucketName });
    const data = await s3.send(listObjectsCommand);
    const objectKeys = data.Contents.map((obj) => obj.Key);

    // Initialize a counter for the number of files processed
    let filesProcessed = 0;

    // Process the object keys and insert data into MongoDB
    for (const objectKey of objectKeys) {
      try {
        // Fetch the object data from S3
        const getObjectCommand = new GetObjectCommand({
          Bucket: bucketName,
          Key: objectKey,
        });
        const objectData = await s3.send(getObjectCommand);

        // Convert the ReadableStream to a Buffer
        const chunks = [];
        const readableStream = objectData.Body;
        if (readableStream instanceof Readable) {
          for await (const chunk of readableStream) {
            chunks.push(chunk);
          }
        }
        const buffer = Buffer.concat(chunks);

        // Insert the data into MongoDB
        const videoChunk = new VideoChunk({
          chunkId: objectKey,
          data: buffer,
        });
        await videoChunk.save();
        filesProcessed++;

        // If the Lambda function is about to time out, break the loop
        if (context.getRemainingTimeInMillis() < 5000) {
          break;
        }
      } catch (err) {
        console.error(`Error processing object ${objectKey}:`, err);
      }
    }

    console.log("Files processed:", filesProcessed);

    // Close the MongoDB connection
    await mongoose.disconnect();

    return { statusCode: 200, body: JSON.stringify({ filesProcessed }) };
  } catch (err) {
    console.error("Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal Server Error" }),
    };
  }
};
